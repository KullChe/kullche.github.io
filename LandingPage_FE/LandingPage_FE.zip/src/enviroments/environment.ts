export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080',
  firebaseConfig : {
    apiKey: 'AIzaSyBPW-TW7GZIejf4Q5oIxzbj7lRxOGo2_TE',
    authDomain: 'module6-59953.firebaseapp.com',
    databaseURL: 'https://module6-59953-default-rtdb.firebaseio.com/',
    projectId: 'module6-59953',
    storageBucket: 'module6-59953.appspot.com',
    messagingSenderId: '44686600614',
    appId: '1:44686600614:web:724d3f2b1b0be9f4fec767',
    measurementId: 'G-3L7X7DPK45'
  }
};
