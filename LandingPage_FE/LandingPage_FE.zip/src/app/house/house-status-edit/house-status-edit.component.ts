import { Component } from '@angular/core';

@Component({
  selector: 'app-house-status-edit',
  templateUrl: './house-status-edit.component.html',
  styleUrls: ['./house-status-edit.component.css']
})
export class HouseStatusEditComponent {

}
