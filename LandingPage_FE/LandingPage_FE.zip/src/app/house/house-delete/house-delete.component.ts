import {Component, OnInit} from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-house-delete',
  templateUrl: './house-delete.component.html',
  styleUrls: ['./house-delete.component.css']
})
export class HouseDeleteComponent implements OnInit{

constructor() {
}

// function1() {
//
//   Swal.fire(
//     ' ',
//     '<h2 style="color: red; font-size: 32px">Có lỗi xảy ra!!!</h2>',
//     'error'
//   )
// }
// function2() {
//
//   Swal.fire(
//     ' ',
//     '<h2 style="color: green; font-size: 32px">Thành công</h2>',
//     'success'
//   )
// }

  ngOnInit(): void {
  }
}
