export interface RatingDTO{
  id?:number;
  rating?: String;
  houseId?:number;
  userId?:number;
  userName?:String;
}
