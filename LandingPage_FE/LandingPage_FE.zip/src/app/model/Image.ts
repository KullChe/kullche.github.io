export interface Image {
  id?: number;
  imageName?: string;
}
