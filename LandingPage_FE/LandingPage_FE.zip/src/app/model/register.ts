export interface Register {
  userName?: string;
  password?: string;
  confirmPassword?: string;
  phone?: string;
  email?: string;
}
