export interface HouseNotImage {
  id?: number;
  houseName?: string;
  houseAddress?: string;
  bedrooms?: number;
  bathrooms?: number;
  rent?: number;
  description?: string;
}
