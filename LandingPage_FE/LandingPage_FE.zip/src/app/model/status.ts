export interface Status {
  id?: number;
  statusName?: string;
}
