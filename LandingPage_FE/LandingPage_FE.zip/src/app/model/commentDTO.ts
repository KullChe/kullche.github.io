export interface CommentDTO {
  id?:number;
  comment?: String;
  house?:number;
  user?:any;
}
