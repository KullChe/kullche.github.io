export interface Rating{
  id?:number;
  houseRating?: String;
  houseId?:number;
  userId?:number;
  userName?:String;
}
