export interface Income {
  houseId?: string;
  month?: string;
}
