export interface OrderDTO {
  id?: number;
  usersId: number;
  houseId: number;
  orderStatusID: number;
  startTime: any;
  endTime: any;
  createTime: any;
}
