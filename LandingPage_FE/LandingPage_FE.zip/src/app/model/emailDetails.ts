export interface EmailDetails{
  recipient?: string;
  msgBody? : string;
  subject? : string;
  attachment?: string;
}
