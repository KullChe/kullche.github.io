export interface OrderStatus {
  id?: number;
  statusName?: string;
}
